
import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SignalService {
  loggedIn = signal<boolean>(!!localStorage.getItem('token'));
  currentUser = signal<any>(this.getStoredUser());

  setSession(token: string, user: any) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    this.loggedIn.set(true);
    this.currentUser.set(user);
  }

  clearSession() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.loggedIn.set(false);
    this.currentUser.set(null);
  }

  getStoredUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }
}
