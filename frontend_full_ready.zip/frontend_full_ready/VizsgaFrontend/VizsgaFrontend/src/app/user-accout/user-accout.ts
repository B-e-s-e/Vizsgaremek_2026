import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../services/api';
import { SignalService } from '../signal-service';

@Component({
  selector: 'app-user-accout',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-accout.html',
  styleUrl: './user-accout.css',
})
export class UserAccoutComponent implements OnInit {
  user: any = null;
  cars: any[] = [];
  bookings: any[] = [];
  services: any[] = [];
  info = '';
  error = '';

  carForm = { marka: '', tipus: '', evjarat: '', rendszam: '', szin: '' };
  bookingForm = { auto_id: '', szolgaltatas_id: '', datum: '', helyszin: '', megjegyzes: '' };

  constructor(private auth: SignalService, private router: Router, private api: ApiService) {}

  ngOnInit(): void {
    this.user = this.auth.getStoredUser();
    if (!this.user) { this.router.navigate(['/login']); return; }
    this.loadData();
  }

  loadData() {
    this.api.me().subscribe({ next: (user) => this.user = user, error: () => this.auth.clearSession() });
    this.api.getAutok().subscribe((res: any) => this.cars = res);
    this.api.getSzolgaltatasok().subscribe((res: any) => this.services = res);
    this.api.getFoglalasok().subscribe((res: any) => this.bookings = res);
  }

  saveCar() {
    this.info = ''; this.error = '';
    this.api.addAuto({ ...this.carForm, evjarat: Number(this.carForm.evjarat) }).subscribe({
      next: () => {
        this.info = 'Az autó sikeresen elmentve.';
        this.carForm = { marka: '', tipus: '', evjarat: '', rendszam: '', szin: '' } as any;
        this.loadData();
      },
      error: (err) => this.error = Object.values(err?.error?.errors || {}).flat().join(' ') || 'Nem sikerült menteni az autót.'
    });
  }

  createBooking() {
    this.info = ''; this.error = '';
    const service = this.services.find((s) => s.id == this.bookingForm.szolgaltatas_id);
    this.api.createFoglalas({
      ...this.bookingForm,
      auto_id: Number(this.bookingForm.auto_id),
      szolgaltatas_id: Number(this.bookingForm.szolgaltatas_id),
      ar: service?.ar || 0,
    }).subscribe({
      next: () => {
        this.info = 'A foglalás rögzítve lett.';
        this.bookingForm = { auto_id: '', szolgaltatas_id: '', datum: '', helyszin: '', megjegyzes: '' };
        this.loadData();
      },
      error: (err) => this.error = Object.values(err?.error?.errors || {}).flat().join(' ') || 'Nem sikerült rögzíteni a foglalást.'
    });
  }

  deleteCar(id: number) {
    if (!confirm('Biztosan törölni szeretnéd ezt az autót?')) return;
    this.info = ''; this.error = '';
    this.api.deleteAuto(id).subscribe({
      next: () => {
        this.info = 'Az autó törölve lett.';
        this.cars = this.cars.filter((c) => c.id !== id);
        this.bookings = this.bookings.filter((b) => b.auto_id !== id);
      },
      error: (err) => this.error = err?.error?.message || 'Nem sikerült törölni az autót.'
    });
  }

  deleteBooking(id: number) {
    if (!confirm('Biztosan törölni szeretnéd ezt a foglalást?')) return;
    this.info = ''; this.error = '';
    this.api.deleteFoglalas(id).subscribe({
      next: () => {
        this.info = 'A foglalás törölve lett.';
        this.bookings = this.bookings.filter((b) => b.id !== id);
      },
      error: (err) => this.error = err?.error?.message || 'Nem sikerült törölni a foglalást.'
    });
  }

  logout() {
    this.auth.clearSession();
    this.router.navigate(['/home']);
  }
}
