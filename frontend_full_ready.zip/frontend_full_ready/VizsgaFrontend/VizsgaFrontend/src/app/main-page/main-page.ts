
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './main-page.html',
  styleUrl: './main-page.css'
})
export class MainPageComponent {
  gallery = ['/owners/beautiful-car-washing-service_23-2149212222.avif','/owners/luxury-black-sports-car-receiving-professional-shampoo-wash-space-text-stunning-undergoing-thorough-luxurious-315730974.webp','/owners/19eecf836b6bba7915a66c85c9baf909.jpg'];
  constructor(private router: Router) {}
  goTo(path: string) { this.router.navigate([path]); }
}
