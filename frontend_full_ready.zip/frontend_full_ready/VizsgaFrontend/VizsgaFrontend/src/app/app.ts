import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavCompComponent } from './nav-comp/nav-comp';
import { FooterCompComponent } from './footer-comp/footer-comp';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavCompComponent, FooterCompComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {}