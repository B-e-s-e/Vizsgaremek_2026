import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-comp',
  standalone: true,
  templateUrl: './footer-comp.html',
  styleUrl: './footer-comp.css'
})
export class FooterCompComponent {}