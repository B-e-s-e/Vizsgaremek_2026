
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SignalService } from '../signal-service';
import { ApiService } from '../services/api';

@Component({
  selector: 'app-login-comp',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login-comp.html',
  styleUrl: './login-comp.css',
})
export class LoginComp {
  inputEmail = '';
  inputPassword = '';
  errorMessage = '';

  constructor(private router: Router, private service: SignalService, private api: ApiService) {}

  login() {
    this.errorMessage = '';
    this.api.login({ email: this.inputEmail, password: this.inputPassword }).subscribe({
      next: (res: any) => {
        this.service.setSession(res.token, res.user);
        this.router.navigate(['/account']);
      },
      error: (err) => this.errorMessage = err?.error?.message || 'Sikertelen bejelentkezés.'
    });
  }

  navToRegister() { this.router.navigate(['/register']); }
}
