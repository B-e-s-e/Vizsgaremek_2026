
import { Routes } from '@angular/router';
import { MainPageComponent } from './main-page/main-page';
import { NotFoundComponent } from './not-found-component/not-found-component';
import { UserAccoutComponent } from './user-accout/user-accout';
import { LoginComp } from './login-comp/login-comp';
import { RegisterComp } from './register-comp/register-comp';
import { OwnersPageComponent } from './owners-page/owners-page';
import { AdminLoginComponent } from './admin-login/admin-login';
import { AdminOrdersComponent } from './admin-orders/admin-orders';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'login', component: LoginComp },
  { path: 'register', component: RegisterComp },
  { path: 'home', component: MainPageComponent },
  { path: 'owners', component: OwnersPageComponent },
  { path: 'account', component: UserAccoutComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'admin', component: AdminOrdersComponent },
  { path: '**', component: NotFoundComponent }
];
