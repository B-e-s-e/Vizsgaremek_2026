
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SignalService } from '../signal-service';
import { ApiService } from '../services/api';

@Component({
  selector: 'app-register-comp',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register-comp.html',
  styleUrl: './register-comp.css',
})
export class RegisterComp {
  name = '';
  phonenumber = '';
  email = '';
  password = '';
  errorMessage = '';

  constructor(private router: Router, private service: SignalService, private api: ApiService) {}

  register() {
    this.errorMessage = '';
    this.api.register({
      nev: this.name,
      phonenumber: this.phonenumber,
      email: this.email,
      password: this.password
    }).subscribe({
      next: (res: any) => {
        this.service.setSession(res.token, res.user);
        this.router.navigate(['/account']);
      },
      error: (err) => this.errorMessage = Object.values(err?.error?.errors || {}).flat().join(' ') || 'Sikertelen regisztráció.'
    });
  }

  navToLogin() { this.router.navigate(['/login']); }
}
