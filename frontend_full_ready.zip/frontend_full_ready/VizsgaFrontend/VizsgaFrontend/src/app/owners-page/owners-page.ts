
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-owners-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './owners-page.html',
  styleUrl: './owners-page.css'
})
export class OwnersPageComponent {
  owners = [
    {
      name: 'Galambosi Dániel',
      role: 'Tanuló',
      image: '/owners/c77fc524-724b-4ffe-8b68-12b994903b9f.jpg',
      text: 'Sosem tervezek hosszú távon előre. Szeretek minden lépésről lépésre megtervezni. Ha problémába ütközök sosem esek kétségbe, hiszen azok azért vannak hogy megoldjuk őket.'
    },
    {
      name: 'Kiss Bálint',
      role: 'Tanuló',
      image: '/owners/peti.jpg',
      text: 'Szeretem az izgalmakat, kihívásokat, s alkalmanként a nehezebb utat választani. Hiszen sosem lehet tudni miben mekkora kihívás rejlik.'
    },
    {
      name: 'Megyery Bese Máté',
      role: 'Tanuló',
      image: '/owners/962e9f57-8911-481a-992c-4355f6e02ce9.jpg',
      text: 'Mindenem a hatékonyság, fontos a lényegretörés. Szeretem a munkám optimalizálni, a kitűzött céljaim hatékonyan elérni.'
    }
  ];
}
