import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../services/api';
import { SignalService } from '../signal-service';

@Component({
  selector: 'app-admin-orders',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-orders.html',
  styleUrl: './admin-orders.css'
})
export class AdminOrdersComponent implements OnInit {
  user: any = null;
  orders: any[] = [];
  loading = true;
  error = '';
  info = '';

  constructor(private api: ApiService, private auth: SignalService, private router: Router) {}

  ngOnInit(): void {
    this.user = this.auth.getStoredUser();
    if (!this.user || this.user.role !== 'admin') {
      this.router.navigate(['/admin-login']);
      return;
    }

    this.load();
  }

  load() {
    this.loading = true;
    this.error = '';
    this.api.getAdminOrders().subscribe({
      next: (res: any) => {
        this.orders = res;
        this.loading = false;
      },
      error: (err) => {
        this.error = err?.error?.message || 'Nem sikerült lekérni a megrendeléseket.';
        this.loading = false;
      }
    });
  }

  deleteOrder(id: number) {
    if (!confirm('Biztosan törölni szeretnéd ezt a megrendelést?')) return;

    this.api.deleteAdminOrder(id).subscribe({
      next: () => {
        this.info = 'A megrendelés törölve lett.';
        this.orders = this.orders.filter((o) => o.id !== id);
      },
      error: (err) => {
        this.error = err?.error?.message || 'Nem sikerült törölni a megrendelést.';
      }
    });
  }

  get totalRevenue(): number {
    return this.orders.reduce((sum, order) => sum + Number(order.ar || 0), 0);
  }
}
