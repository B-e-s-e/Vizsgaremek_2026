import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../services/api';
import { SignalService } from '../signal-service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-login.html',
  styleUrl: './admin-login.css'
})
export class AdminLoginComponent {
  email = 'admin@vizsga.hu';
  password = 'admin123';
  error = '';

  constructor(private api: ApiService, private auth: SignalService, private router: Router) {}

  login() {
    this.error = '';
    this.api.login({ email: this.email, password: this.password }).subscribe({
      next: (res: any) => {
        if (res?.user?.role !== 'admin') {
          this.error = 'Ez a felület csak admin fiókkal érhető el.';
          return;
        }
        this.auth.setSession(res.token, res.user);
        this.router.navigate(['/admin']);
      },
      error: (err) => this.error = err?.error?.message || 'Sikertelen admin bejelentkezés.'
    });
  }
}
