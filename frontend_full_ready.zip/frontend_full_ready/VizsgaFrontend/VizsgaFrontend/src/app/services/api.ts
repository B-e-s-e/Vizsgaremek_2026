import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private baseUrl = 'http://127.0.0.1:8000/api';

  constructor(private http: HttpClient) {}

  private authOptions() {
    const token = localStorage.getItem('token') || '';
    return { headers: new HttpHeaders({ Authorization: `Bearer ${token}` }) };
  }

  login(data: any) { return this.http.post(`${this.baseUrl}/login`, data); }
  register(data: any) { return this.http.post(`${this.baseUrl}/register`, data); }
  me() { return this.http.get(`${this.baseUrl}/me`, this.authOptions()); }
  logout() { return this.http.post(`${this.baseUrl}/logout`, {}, this.authOptions()); }
  getAutok() { return this.http.get(`${this.baseUrl}/my-autok`, this.authOptions()); }
  addAuto(data: any) { return this.http.post(`${this.baseUrl}/my-autok`, data, this.authOptions()); }
  deleteAuto(id: number) { return this.http.delete(`${this.baseUrl}/my-autok/${id}`, this.authOptions()); }
  getSzolgaltatasok() { return this.http.get(`${this.baseUrl}/szolgaltatasok`); }
  getFoglalasok() { return this.http.get(`${this.baseUrl}/my-foglalasok`, this.authOptions()); }
  createFoglalas(data: any) { return this.http.post(`${this.baseUrl}/my-foglalasok`, data, this.authOptions()); }
  deleteFoglalas(id: number) { return this.http.delete(`${this.baseUrl}/my-foglalasok/${id}`, this.authOptions()); }
  getAdminOrders() { return this.http.get(`${this.baseUrl}/admin/orders`, this.authOptions()); }
  deleteAdminOrder(id: number) { return this.http.delete(`${this.baseUrl}/admin/orders/${id}`, this.authOptions()); }
}
