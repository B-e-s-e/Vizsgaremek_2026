import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SignalService } from '../signal-service';

@Component({
  selector: 'app-nav-comp',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './nav-comp.html',
  styleUrl: './nav-comp.css'
})
export class NavCompComponent {
  constructor(private router: Router, public auth: SignalService) {}

  get isLoggedIn(): boolean {
    return this.auth.loggedIn();
  }

  get isAdmin(): boolean {
    return this.auth.currentUser()?.role === 'admin';
  }

  navTo(path: string): void {
    this.router.navigate([path]);
  }

  logout(): void {
    this.auth.clearSession();
    this.router.navigate(['/home']);
  }
}
