Frontend inditas:
1. cd VizsgaFrontend/VizsgaFrontend
2. npm install
3. ng serve -o

Uj admin oldalak:
- /admin-login
- /admin

Admin belepes:
email: admin@vizsga.hu
jelszo: admin123
